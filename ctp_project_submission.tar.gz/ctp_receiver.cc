// src/ctp_receiver.cc
// CTP Receiver - receives files using the CTP protocol

#include "include/ctp.h"
#include "src/ctp.cc"

int main(int argc, char* argv[]) {
    return run_receiver(argc, argv);
}
