#include "include/ctp.h"
#include "src/ctp.cc"

int main(int argc, char* argv[]) {
    return run_sender(argc, argv);
}